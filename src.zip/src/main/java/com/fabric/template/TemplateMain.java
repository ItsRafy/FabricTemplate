package com.fabric.template;

import net.fabricmc.api.ModInitializer;

public class TemplateMain implements ModInitializer {

	@Override
	public void onInitialize() {

	}
}
