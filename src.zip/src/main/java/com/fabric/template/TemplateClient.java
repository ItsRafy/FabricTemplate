package com.fabric.template;

import net.fabricmc.api.ClientModInitializer;

public class TemplateClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {

    }
}
